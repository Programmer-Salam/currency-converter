<!DOCTYPE html>
<html>
<head>
    <title>Currency Converter</title>
    <style>
   select {
    width: 160px;
  font-family: Arial, sans-serif;
  font-size: 16px;
  padding: 8px;
  border-radius: 4px;
  border: 1px solid #ccc;
  box-shadow: none;
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
  background-image: url('data:image/svg+xml;utf8,<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"/></svg>');
  background-repeat: no-repeat;
  background-position: right 8px center;
  background-size: 12px 12px;
}


        input[type=submit] {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 4px;
        }

        input[type=submit]:hover {
            background-color: #3e8e41;
        }
    </style>
</head>
<body>

<h1>Currency Converter</h1>

<form action="{{ route('convert') }}" method="POST">
    @csrf
    <label for="from_currency">From:</label>
    <select name="from_currency" id="from_currency">
        @foreach($currencies as $currency => $value)
            <option value="{{ $currency }}">{{ $currency }}</option>
        @endforeach
    </select>
<br><br>
    <label for="to_currency">To:</label>
    <select name="to_currency" id="to_currency">
        @foreach($currencies as $currency => $value)
            <option value="{{ $currency }}">{{ $currency }}</option>
        @endforeach
    </select>
    <br><br>

    <label for="amount">Amount:</label>
    <input type="number" name="amount" id="amount" required>

    <input type="submit" value="Convert">
</form>

<br>

</body>
</html>
