

<?php $__env->startSection('content'); ?>
    <h1>Currency Converter</h1>

    <form method="POST" action="<?php echo e(url('/convert')); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label for="from_currency">From Currency:</label>
            <select name="from_currency" id="from_currency">
                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($currency['code']); ?>"><?php echo e($currency['name']); ?> (<?php echo e($currency['code']); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="to_currency">To Currency:</label>
            <select name="to_currency" id="to_currency">
                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($currency['code']); ?>"><?php echo e($currency['name']); ?> (<?php echo e($currency['code']); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="amount">Amount:</label>
            <input type="text" name="amount" id="amount">
        </div>

        <div>
            <button type="submit">Convert</button>
        </div>
    </form>

    <?php if(!empty($result)): ?>
        <h2>Conversion Result:</h2>
        <p><?php echo e($result['amount']); ?> <?php echo e($result['from_currency']); ?> = <?php echo e($result['converted_amount']); ?> <?php echo e($result['to_currency']); ?></p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\currency-converter\resources\views/countries.blade.php ENDPATH**/ ?>