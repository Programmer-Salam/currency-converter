<!DOCTYPE html>
<html>
<head>
    <title>Currency Converter Result</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-3">Currency Converter Result</h1>

        <div class="row">
            <div class="col-md-6">
                <p class="mb-0">Converted <strong><?php echo e($amount); ?></strong> <strong><?php echo e($fromCurrency); ?></strong> to <strong><?php echo e($convertedAmount); ?></strong> <strong><?php echo e($toCurrency); ?></strong>.</p>
            </div>
            <div class="col-md-6">
                <p class="mb-0">Exchange rate: 1 <strong><?php echo e($fromCurrency); ?></strong> = <strong><?php echo e($exchangeRate); ?></strong> <strong><?php echo e($toCurrency); ?></strong>.</p>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-md-12">
                <a href="<?php echo e(route('currency-converter')); ?>" class="btn btn-primary">Back to Currency Converter</a>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\HP\currency-converter\resources\views/currency_converter/result.blade.php ENDPATH**/ ?>