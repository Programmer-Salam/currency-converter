<?php
namespace App\Http\Controllers;
use GuzzleHttp\Client;
use Illuminate\Http\Request;


class CurrencyConverterController extends Controller
{
    public function index()
    {
        // Initialize Guzzle client with base URI
        $client = new Client([
            'base_uri' => 'https://v6.exchangerate-api.com/v6/Your_API_Key/',
        ]);

        // Make GET request to API to retrieve list of currencies
        $response = $client->request('GET', 'latest/USD');

        // Decode JSON response and get list of currencies
        $data = json_decode($response->getBody(), true);
        $currencies = $data['conversion_rates'];

        // Display list of currencies to user
        return view('currency_converter.index', ['currencies' => $currencies]);
    }

    public function convert(Request $request)
    {
        // Initialize Guzzle client with base URI
        $client = new Client([
            'base_uri' => 'https://v6.exchangerate-api.com/v6/Your_API_Key/',
        ]);

        // Get parameters from form submission
        $fromCurrency = $request->input('from_currency');
        $toCurrency = $request->input('to_currency');
        $amount = $request->input('amount');

        // Make GET request to API to retrieve exchange rate
        $response = $client->request('GET', 'pair/' . $fromCurrency . '/' . $toCurrency);

        // Decode JSON response and get exchange rate
        $data = json_decode($response->getBody(), true);
        $exchangeRate = $data['conversion_rate'];

        // Calculate converted amount
        $convertedAmount = $amount * $exchangeRate;

        // Display result to user
        return view('currency_converter.result', [
            'fromCurrency' => $fromCurrency,
            'toCurrency' => $toCurrency,
            'amount' => $amount,
            'convertedAmount' => $convertedAmount,
            'exchangeRate' => $exchangeRate,
        ]);
    }
}
